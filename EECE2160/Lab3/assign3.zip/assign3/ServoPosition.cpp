#include <iostream>
#include "GPIO.h"
using namespace std;

int main() {
int servoNumber = 0;
int angle = 0;
cout << "Please enter a Servo number between 1 and 5" << endl <<
"Servo 1: Base" << endl <<
"Servo 2: Bicep" << endl <<
"Servo 3: Elbow" << endl <<
"Servo 4: Wrist" << endl <<
"Servo 5: Gripper" << endl;
cin >> servoNumber;
while(servoNumber > 5 || servoNumber < 1) {
cout << "Please enter a valid Servo number." << endl;
cin >> servoNumber;
}
int portNumber = -1;
if(servoNumber == 1)
   portNumber = 13;
if(servoNumber == 2)
   portNumber = 10;
if(servoNumber == 3)
   portNumber = 11;
if(servoNumber == 4)
   portNumber = 12;
if(servoNumber == 5)
   portNumber = 0;

cout << "Please enter the position for the servo, given as an angle in degrees" << endl;
cin >> angle;
while(angle > 180 || angle < 0) {
cout << "Please enter a valid angle number between 0 and 180." << endl;
cin >> angle;
}
int position = ((double)angle * 10) + 600;

GPIO gpio(portNumber);
gpio.GeneratePWM(20000, position, 400);
return 0;

}
