#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <sys/mman.h>
#include <fcntl.h>
#include "RoboticArm.h"
using namespace std;

int main()
{
	//wiimote stuff
	int fd;
	fd = open("/dev/input/event2", O_RDONLY | O_NONBLOCK);
	if (fd == -1)
	{
		std::cerr << "Error: Could not open event file - forgot sudo?\n";
		exit(1);
	}
	
	RoboticArm arm;
	//default angles
	int angleBase = 90;
	int angleBicep = 90;
	int angleElbow = 90;
	int angleWrist = 90;
	int angleGripper = 90;
	int code = 0;
	int value = 0;
	//up or down
	bool up;
	while (true) {
        char buffer[32];
        read(fd, buffer, 32);
        // Extract code (byte 10) and value (byte 12) from packet
        code = buffer2[10];
        value = buffer2[12];
		
		if(code == 103 && value == 1) {
			up = true;
		}
		
		if(code == 108 && value == 1) {
			up = false;
		}
		
		//up
		if(up == true) {
			//minus (base)
			if (code == 156) {
				if (value = 1) {
					if(anglebase < 180)
						angleBase++;
				}
			}
		
			//home (bicep)
			if (code == 60) {
				if (value = 1) {
					if(angleBicep < 180)
						angleBicep++;
				}
			}
		
			//plus (elbow)
			if (code == 151) {
				if (value = 1) {
					if(angleElbow < 180)
						angleElbow++;
				}
			}
		
			//one (wrist)
			if (code == 1) {
				if (value = 1) {
					if(angleWrist < 180)
						angleWrist++;
				}
			}
		
			//two (gripper)
			if (code == 2) {
				if (value = 1) {
					if(angleGripper < 180)
						angleGripper++;
				}
			}
		}
		
		//down
		if(up == false) {
			//minus (base)
			if (code == 156) {
				if (value = 1) {
					if(angleBase > 0)
						angleBase--;
				}
			}
		
			//home (bicep)
			if (code == 60) {
				if (value = 1) {
					if(angleBicep > 0)
						angleBicep--;
				}
			}
		
			//plus (elbow)
			if (code == 151) {
				if (value = 1) {
					if(angleElbow > 0)
						angleElbow--;
				}
			}
		
			//one (wrist)
			if (code == 1) {
				if (value = 1) {
					if(angleWrist > 0)
						angleWrist--;
				}
			}
		
			//two (gripper)
			if (code == 2) {
				if (value = 1) {
					if(angleGripper > 0)
						angleGripper--;
				}
			}
		}
		
		//move all servos to correct positions
		arm.MoveServo(0, angleBase, 45);
		arm.MoveServo(1, angleBicep, 45);
		arm.MoveServo(2, angleElbow, 45);
		arm.MoveServo(3, angleWrist, 45);
		arm.MoveServo(4, angleGripper, 45);
	}
}