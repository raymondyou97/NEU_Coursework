bluez-simple-agent hci0 8C:56:C5:5A:2F:2B
bluez-test-device trusted 8C:56:C5:5A:2F:2B yes
bluez-test-input connect 8C:56:C5:5A:2F:2B
