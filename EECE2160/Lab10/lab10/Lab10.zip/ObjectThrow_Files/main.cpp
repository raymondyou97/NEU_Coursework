#include "RoboticArm.h"
#include <unistd.h>
int main()
{
	RoboticArm robotic_arm;
	while (true)
	{
    robotic_arm.MoveServo(0, 70, 45);
    robotic_arm.MoveServo(1, 30, 45);
    robotic_arm.MoveServo(2, 60, 45);
    robotic_arm.MoveServo(4, 180, 45);
    sleep(3);
    robotic_arm.MoveServo(4, 0, 45);
    sleep(3);
    robotic_arm.MoveServo(1, 70, 500);
    robotic_arm.MoveServo(2, 90, 360);
    robotic_arm.MoveServo(4, 180, 2000);
    robotic_arm.MoveServo(2, 180, 180);
    
    
    
    
    
    return 0;
	}
}
